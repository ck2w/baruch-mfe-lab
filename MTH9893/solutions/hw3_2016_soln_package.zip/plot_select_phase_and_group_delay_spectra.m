%--------------------------------------------------------------------------------------------------
%
% script:  plot_select_phase_and_group_delay_spectra.m
% descrip: plots the phase and group delay spectra for hw3.
%
% author:  JN Damask
%
%--------------------------------------------------------------------------------------------------

% defs  -- from homework
T       = 1;
tau     = 1;
tau_pos = 1/2;
tau_neg = 3/2;
waxis   = 10.^[-2: 0.02: 2];

fields  = {'ideal_delay', 'box', 'ema', 'polyema', 'imacd'};

% phase spectra generators
H_phase_gen.ideal_delay = @(w)(tau + 0 * w);
H_phase_gen.box         = @(w)(-w * T / 2);
H_phase_gen.ema         = @(w)(-unwrap(atan(w * tau)));
H_phase_gen.polyema     = @(w)(-2 * unwrap( atan(w * tau)));
H_phase_gen.imacd       = @(w)(-unwrap( atan(w * tau_pos) + atan(w * tau_neg)));

% group-delay spectra generators
H_gd_gen.ideal_delay = @(w)(tau + 0 * w);
H_gd_gen.box         = @(w)(T/2 + 0 * w);
H_gd_gen.ema         = @(w)(tau ./ (1 + (w*tau).^2));
H_gd_gen.polyema     = @(w)(2 * tau ./ (1 + (w*tau).^2));
H_gd_gen.imacd       = @(w)(tau_pos ./ (1+(w*tau_pos).^2) + tau_neg ./ (1+(w*tau_neg).^2) );

% render plots
for f = 1: length(fields),
    
   figure(f); clf
   for k = 1: 2, ax(k) = subplot(2,1,k); end; linkaxes(ax, 'x');
   
   axes(ax(1));
   semilogx(waxis, H_phase_gen.(fields{f})(waxis)); grid on
   title(['phase spectrum for ' fields{f}]);
   
   axes(ax(2));
   semilogx(waxis, H_gd_gen.(fields{f})(waxis)); grid on
   title(['group-delay spectrum for ' fields{f}]);
   
end





