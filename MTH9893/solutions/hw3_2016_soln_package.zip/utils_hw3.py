__author__ = 'yifan'
# This script is for Math9893 at Baruch College
# utils for hw3


import numpy as np


def make_h_box(Nbox, Nwindow):
    '''
   Returns a box-averager impulse response

    :param Nbox:
    :param Nwindow:
    :return: box-averager impulse response
    '''

    h = np.concatenate((1. / Nbox * np.ones(Nbox), np.zeros(Nwindow - Nbox)))
    return h


def make_h_delta(k, Nwindow):
    '''
    Returns a ideal delay

    :param k:
    :param Nwindow:
    :return: a ideal delay
    '''
    h = np.zeros(Nwindow)
    h[k-1] = 1.
    return h


def make_h_ema(Neff, Nwindow):
    '''
    Return a truncated ema impulse response. Due to the truncation
    the gain is less than unity.

    :param Neff:
    :param Nwindow:
    :return: truncated ema impulse response
    '''

    p = Neff / (Neff + 1.)
    n = np.array(range(Nwindow))
    h = (1. - p) * (p ** n)
    return h


def make_h_macd(Neff_pos, Neff_neg, Nwindow):
    '''
    Returns a truncated macd response

    :param Neff_pos:
    :param Neff_neg:
    :param Nwindow:
    :return: truncated macd response
    '''

    h_pos = make_h_ema(Neff_pos, Nwindow)
    h_neg = make_h_ema(Neff_neg, Nwindow)
    h = h_pos - h_neg
    return h


def make_h_macd_m1(Neff_pos, Neff_neg, Nwindow):
    '''
    Returns a first-moment representation of an macd response.

    :param Neff_pos:
    :param Neff_neg:
    :param Nwindow:
    :return: first-moment representation of an macd response
    '''

    h_pos = make_h_delta(Neff_pos, Nwindow)
    h_neg = make_h_delta(Neff_neg, Nwindow)
    h = h_pos - h_neg
    return h


def make_h_unitstep(Nwindow):
    '''
    Returns a truncated unit-step response

    :param Nwindow:
    :return: truncated unit-step response
    '''

    h = np.ones(Nwindow)
    return h


def make_h_box_diff(Nbox, Nwindow):
    '''
    Returns a differencer impulse response where the positive
    and negative arms are equal-length boxes.
    :param Nbox:
    :param Nwindow:
    :return: boxes differencer impulse response
    '''

    h = np.concatenate(( 1./Nbox * np.ones(Nbox), -1./Nbox * np.ones(Nbox), np.zeros(Nwindow - 2*Nbox)))
    return h


def make_h_ema_poly1(Neff, Nwindow):
    '''
    Returns a unit gain ema with linear polynomial coefficient
    :param Neff:
    :param Nwindow:
    :return:
    '''

    p = (Neff/2.) / ((Neff/2.) + 1)
    h = (1-p) * (1-p) * np.array(range(1, 1+Nwindow)) * (p**np.array(range(Nwindow)))
    return h


def make_h_macd_poly1(Neff, Nwindow):
    '''
    Make a degenerate macd. The positive arm is an ema with Neff_pos = Neff / 3.
    The negative arm is a polynomial-coeff ema with Neff_neg = Neff.
    :param Neff:
    :param Nwindow:
    :return:
    '''

    h_pos = make_h_ema(Neff / 3., Nwindow)
    h_neg = make_h_ema_poly1(Neff, Nwindow)
    h = h_pos - h_neg
    return h


def make_h_lifted_macd_poly(Neff, Nwindow):
    '''
    Makes a lifted macd-poly filter, which is like a band-limited ema.
    The gain is unity. 'Lift' means that I have convolved an macd-poly
    impulse response with a unit step.
    :param Neff:
    :param Nwindow:
    :return:
    '''
    h_macd_poly = make_h_macd_poly1(Neff, Nwindow)
    g = 2. * Neff / 3.
    h_lift = 1. / g * np.cumsum(h_macd_poly)
    return h_lift


def calc_box_ema_spectra_mse(Neff, Nbox, Nwindow):
    '''
    Builds box and ema regularization windows, computes the fft,
    and based on the first-half of the fft amplitude spectrum
    (the positive-frequency part) compute the mean-square error
    between the cumulative box and ema spectra.
    :param Neff: effective length of ema
    :param Nbox: width of box
    :param Nwindow: must be 2 ** m long, and >= 8 x Neff
    :return:
    '''

    # construct windows
    h_box = make_h_box(Nbox, Nwindow)
    h_ema = make_h_ema(Neff, Nwindow)

    # take fft's
    fft_box = np.fft.fft(h_box)
    fft_ema = np.fft.fft(h_ema)

    # compute cumulative sums
    S_fft_box = np.cumsum(np.abs(fft_box[:Nwindow/2]))
    S_fft_ema = np.cumsum(np.abs(fft_ema[:Nwindow/2]))

    # error
    mse = np.sum( (S_fft_box - S_fft_ema) ** 2) / Nwindow
    return mse


def calc_box_macd_spectra_mse(Neff, Nbox, Nwindow):
    '''
    Builds box and macd regularization windows, computes the fft,
    and based on the first-half of the fft amplitude spectrum
    (the positive-frequency part) compute the mean-square error
    between the cumulative box and ema spectra.
    :param Neff: effective length of ema
    :param Nbox: width of box
    :param Nwindow: must be 2 ** m long, and >= 8 x Neff
    :return:
    '''

    # construct windows
    h_box_diff = make_h_box_diff(Nbox, Nwindow)

    h_cand = make_h_macd(Neff, 3*Neff, Nwindow)
    h_macd = switch_to_composite_unity_gauge(h_cand)

    # take fft's
    fft_boxd = np.fft.fft(h_box_diff)
    fft_macd = np.fft.fft(h_macd)

    # compute cumulative sums
    S_fft_boxd = np.cumsum(np.abs(fft_boxd[:Nwindow]))
    S_fft_macd = np.cumsum(np.abs(fft_macd[:Nwindow]))

    # error
    mse = np.sum( (S_fft_boxd - S_fft_macd) ** 2) / Nwindow
    return mse


def calc_macd_lift_spectra_mse(Neff_lift, Neff_ema, Nwindow):
    '''
    Builds ema and lifted macd-poly regularization windows, computes the fft,
    and based on the first-half of the fft amplitude spectrum
    (the positive-frequency part) compute the mean-square error
    between the cumulative box and ema spectra.
    :param Neff_lift: effective length parameter of lifted ema
    :param Neff_ema: effective length of ema
    :param Nwindow: must be 2 ** m long, and >= 8 x Neff
    :return:
    '''

    # construct windows
    h_ema = make_h_ema(Neff_ema, Nwindow)
    h_lift = make_h_lifted_macd_poly(Neff_lift, Nwindow)

    # take fft's
    fft_ema = np.fft.fft(h_ema)
    fft_lift = np.fft.fft(h_lift)

    # compute cumulative sums
    S_fft_ema = np.cumsum(np.abs(fft_ema[:Nwindow/2]))
    S_fft_lift = np.cumsum(np.abs(fft_lift[:Nwindow/2]))

    # error
    mse = np.sum( (S_fft_ema - S_fft_lift) ** 2) / Nwindow
    return mse


def switch_to_composite_unity_gauge(h_in):
    '''
    For zero-gain impulse functions, this function changes the gauge
    so that the sum of positive values is unity, and therefore, by
    symmetry, the negative arm has unit gain.
    :param h_in:
    :return:
    '''

    S = np.sum( h_in[h_in>0] )
    h = h_in / S
    return h


def cconv(a, b):
    '''
    Return circular convolution of two real value array
    :param a:
    :param b:
    :return:
    '''

    a = np.asarray(a)
    b = np.asarray(b)

    return np.fft.ifft(np.fft.fft(a) * np.fft.fft(b)).real


def main():
    pass


if __name__ == '__main__':
    main()
