__author__ = 'yifan'
# This script is for Math9893 at Baruch College
# This script refers to hw #3
# Please uncomment each function in main() to test


import matplotlib.pyplot as plt
import math
import numpy as np
import pandas as pd
from scipy.optimize import minimize

import utils_hw3

root_path = '/home/yifan/PycharmProjects'
quotes_path = root_path + '/Baruch/math9893/jpm_quotes.csv'
trades_path = root_path + '/Baruch/math9893/jpm_trades.csv'

quotes = pd.read_csv(quotes_path)
trades = pd.read_csv(trades_path)

def study_window_spectral_matching():
    '''
    Studies how to match window shapes within the same class using spectral methods.
    :return: None
    '''

    # Defs
    Nwindow = 1024
    Nbox = 16

    ## Data
    prices = quotes['mid']
    Npx_series = len(prices)

    ## Box and Ema

    # 1) Using indicative Neff, plot impulse response, plot amplitude spectra.
    Neff = Nbox / (1 - math.exp(-1))
    h_box = utils_hw3.make_h_box(Nbox, Nwindow)
    h_ema = utils_hw3.make_h_ema(Neff, Nwindow)

    fig1 = plt.figure()
    ax = [fig1.add_subplot(2, 2, k+1) for k in range(4)]

    ax[0].step(range(len(h_box)), h_box)
    ax[0].plot(h_ema, 'r--')
    ax[0].set_ylim([-0.25, 0.25])
    ax[0].grid(True)
    ax[0].set_title('Box and Ema impulse response')

    fft_h_box = np.abs(np.fft.fft(h_box))
    fft_h_ema = np.abs(np.fft.fft(h_ema))

    ax[1].grid(True)
    ax[1].plot(fft_h_box)
    ax[1].plot(fft_h_ema, 'r--')
    ax[1].set_title('Box and Ema spectra')

    ax[2].grid(True)
    ax[2].plot(np.cumsum(fft_h_box[:Nwindow/2]))
    ax[2].plot(np.cumsum(fft_h_ema[:Nwindow/2]), 'r--')
    ax[2].set_title('Energy Capture, Box and Ema')

    # 2) optimize Neff such that the energy capture is maximized on an MSE basis
    obj_ema = lambda x: utils_hw3.calc_box_ema_spectra_mse(x, Nbox, Nwindow)
    res = minimize(obj_ema, Nbox)
    Neff_ema_opt = res.x[0]
    mse_ema_opt = res.fun

    h_ema_opt = utils_hw3.make_h_ema(Neff_ema_opt, Nwindow)
    fft_h_ema_opt = np.abs(np.fft.fft(h_ema_opt))

    ax[0].plot(h_ema_opt, 'k')
    ax[1].plot(fft_h_ema_opt, 'k')
    ax[2].plot(np.cumsum(fft_h_ema_opt[:Nwindow/2]), 'k')

    # 3) compute overlap integral
    box_ema_overlap = np.sum(h_ema_opt * h_box) / np.sqrt(np.sum(h_ema_opt ** 2) * np.sum(h_box ** 2))
    print 'Neff_ema_opt: ', Neff_ema_opt
    print 'box/ema overlap: ', box_ema_overlap

    # 4) convolve with px data
    cand = np.convolve(h_box, prices - prices[0]) + prices[0]
    box_px = cand[:len(prices)]

    cand = np.convolve(h_ema_opt, prices - prices[0]) + prices[0]
    ema_opt_px = cand[:len(prices)]

    ax[3].grid(True)
    ax[3].plot(box_px)
    ax[3].plot(ema_opt_px, 'k')
    ax[3].set_title('Box and Ema Smooths')

    ## Ema and Lifted MACD

    # 1) Using indicative Neff, plot impulse response, plot amplitude spectra
    Neff_ema = Nbox
    Neff_lift = Neff_ema

    h_ema = utils_hw3.make_h_ema(Neff_ema, Nwindow)
    h_lift = utils_hw3.make_h_lifted_macd_poly(Neff_lift, Nwindow)

    fig2 = plt.figure()
    ax = [fig2.add_subplot(2, 2, k+1) for k in range(4)]

    ax[0].grid(True)
    ax[0].plot(h_ema)
    ax[0].plot(h_lift, 'r--')
    ax[0].set_ylim([-0.25, 0.25])
    ax[0].set_title('Ema and Lifted ema impulse responses')

    fft_h_ema = np.abs(np.fft.fft((h_ema)))
    fft_h_lift = np.abs(np.fft.fft(h_lift))

    ax[1].grid(True)
    ax[1].plot(fft_h_ema)
    ax[1].plot(fft_h_lift, 'r--')
    ax[1].set_title('Ema an Lifted ema spectra')

    ax[2].grid(True)
    ax[2].plot(np.cumsum(fft_h_ema[:Nwindow/2]))
    ax[2].plot(np.cumsum(fft_h_lift[:Nwindow/2]))
    ax[2].set_title('Energy Capture, Ema and Lifted ema')

    # 2) optimize Neff such that the energy capture is maximized on an MSE basis
    obj_lift = lambda x: utils_hw3.calc_macd_lift_spectra_mse(x, Neff_ema, Nwindow)
    res = minimize(obj_lift, Neff_ema)
    Neff_lift_opt = res.x[0]
    mse_lift_opt = res.fun

    h_lift_opt = utils_hw3.make_h_lifted_macd_poly(Neff_lift_opt, Nwindow)
    fft_h_lift_opt = np.abs(np.fft.fft(h_lift_opt))

    ax[0].plot(h_lift_opt, 'k')
    ax[1].plot(fft_h_lift_opt, 'k')
    ax[2].plot(np.cumsum(fft_h_lift_opt[:Nwindow/2]), 'k')

    # 3) compute overlap integral
    ema_lift_overlap = np.sum(h_lift_opt * h_ema) / np.sqrt(np.sum(h_lift_opt ** 2) * np.sum(h_ema ** 2))
    print 'Neff_lift_opt: ', Neff_lift_opt
    print 'ema/lift overlap: ', ema_lift_overlap

    # 4) convolve with px data
    cand = np.convolve(h_ema, prices - prices[0]) + prices[0]
    ema_px = cand[:len(prices)]

    cand = np.convolve(h_lift_opt, prices - prices[0]) + prices[0]
    lift_opt_px = cand[:len(prices)]

    ax[3].grid(True)
    ax[3].plot(ema_px)
    ax[3].plot(lift_opt_px, 'k')
    ax[3].set_title('Ema and Lifted-Ema Smooths')

    ## Box-Differencer and Ema-Differencer (MACD)

    # 1) Using indicative Neff, plot impulse response, plot amplitude spectra.
    Neff_pos = Nbox / 3
    Neff_neg = Nbox
    h_box_diff = utils_hw3.make_h_box_diff(Nbox, Nwindow)

    h_cand = utils_hw3.make_h_macd(Neff_pos, Neff_neg, Nwindow)
    h_macd = utils_hw3.switch_to_composite_unity_gauge(h_cand)

    fig3 = plt.figure()
    ax = [fig3.add_subplot(2, 2, k+1) for k in range(4)]

    ax[0].grid(True)
    ax[0].step(range(len(h_box_diff)), h_box_diff)
    ax[0].plot(h_macd, 'r--')
    ax[0].set_ylim([-0.25, 0.25])
    ax[0].set_title('BoxDiff and MACD impulse response')

    fft_h_box_diff = np.abs(np.fft.fft(h_box_diff))
    fft_h_macd = np.abs(np.fft.fft(h_macd))

    ax[1].grid(True)
    ax[1].plot(fft_h_box_diff)
    ax[1].plot(fft_h_macd, 'r--')
    ax[1].set_title('BoxDiff and MACD spectra')

    ax[2].grid(True)
    ax[2].plot(np.cumsum(fft_h_box_diff[:Nwindow/2]))
    ax[2].plot(np.cumsum(fft_h_macd[:Nwindow/2]))
    ax[2].set_title('Energy Capture, BoxDiff and MACD')

    # 2) optimize Neff such that the energy capture is maximized on an MSE basis
    obj_macd = lambda x: utils_hw3.calc_box_macd_spectra_mse(x, Nbox, Nwindow)
    res = minimize(obj_macd, 0.5*Nbox)
    Neff_pos_opt = res.x[0]
    mse_macd_opt = res.fun

    h_cand = utils_hw3.make_h_macd(Neff_pos_opt, 3*Neff_pos_opt, Nwindow)
    h_macd_opt = utils_hw3.switch_to_composite_unity_gauge(h_cand)
    fft_h_macd_opt = np.abs(np.fft.fft(h_macd_opt))

    ax[0].plot(h_macd_opt, 'k')
    ax[1].plot(fft_h_macd_opt, 'k')
    ax[2].plot(np.cumsum(fft_h_macd_opt[:Nwindow/2]), 'k')

    # 3) compute overlap integral
    boxdiff_macd_overlap = np.sum(h_macd_opt * h_box_diff) / np.sqrt(np.sum(h_macd_opt ** 2) * np.sum(h_box_diff ** 2))
    print 'Neff_pos_opt: ', Neff_pos_opt, ' Neff_neg_opt: ', 3*Neff_pos_opt
    print 'boxdiff/macd overlap: ', boxdiff_macd_overlap

    # 4) convolve with px data
    cand = np.convolve(h_box_diff, prices - prices[0]) + prices[0]
    boxd_px = cand[:len(prices)]

    cand = np.convolve(h_macd_opt, prices - prices[0]) + prices[0]
    macd_opt_px = cand[:len(prices)]

    ax[3].grid(True)
    ax[3].plot(boxd_px)
    ax[3].plot(macd_opt_px, 'k')
    ax[3].set_title('BoxDiff and Macd Smooths')

    plt.show()


def study_phase_spectra():
    '''
    Studies shows phase and group-delay spectrum of each function.
    :return:
    '''

    T = 1
    tau = 1
    tau_pos = 1./2
    tau_neg = 3./2

    # the grid on which the plot is going to
    grid = 10. ** np.linspace(-2., 2., 500)
    fig = plt.figure()
    ax = [fig.add_subplot(5, 2, k+1) for k in range(10)]

    # plot phase and group delay for h1
    def phase_h1(w):
        r = np.cos(-w*tau)
        i = np.sin(-w*tau)
        return np.arctan2(i, r)

    def grp_h1(w):
        return tau + 0*w

    ax[0].plot(grid, np.unwrap(phase_h1(grid)))
    ax[0].set_title('phase spectrum for h1')
    ax[0].set_xscale('log')

    ax[1].plot(grid, grp_h1(grid))
    ax[1].set_title('group delay for h1')
    ax[1].set_xscale('log')

    # plot phase and group delay for h2
    def phase_h2(w):
        r = np.cos(-w*T/2.) * np.sin(w*T/2.) / (w*T/2.)
        i = np.sin(-w*T/2.) * np.sin(w*T/2.) / (w*T/2.)
        return np.arctan2(i, r)

    def grp_h2(w):
        # here we are assuming that the discontinuous points are excluded
        return T/2. + 0*w

    ax[2].plot(grid, np.unwrap(phase_h2(grid)))
    ax[2].set_title('phase spectrum for h2')
    ax[2].set_xscale('log')

    ax[3].plot(grid, grp_h2(grid))
    ax[3].set_title('group delay for h2')
    ax[3].set_xscale('log')

    # plot phase and group delay for h3
    def phase_h3(w):
        r = 1.
        i = -w*tau
        return np.arctan2(i, r)

    def grp_h3(w):
        return tau / (1. + (w**2)*(tau**2))

    ax[4].plot(grid, np.unwrap(phase_h3(grid)))
    ax[4].set_title('phase spectrum for h3')
    ax[4].set_xscale('log')

    ax[5].plot(grid, grp_h3(grid))
    ax[5].set_title('group delay for h3')
    ax[5].set_xscale('log')

    # plot phase and group delay for h4
    def phase_h4(w):
        r = 1. - (w**2)*(tau**2)
        i = -2.*w*tau
        return np.arctan2(i, r)

    def grp_h4(w):
        return 2. * tau / (1. + (w**2)*(tau**2))

    ax[6].plot(grid, np.unwrap(phase_h4(grid)))
    ax[6].set_title('phase spectrum for h4')
    ax[6].set_xscale('log')

    ax[7].plot(grid, grp_h4(grid))
    ax[7].set_title('group delay for h4')
    ax[7].set_xscale('log')

    # plot phase and group delay for h5
    def phase_h5(w):
        r = (w**2) * tau_pos * tau_neg -1
        i = w*(tau_pos + tau_neg)
        return np.arctan2(i, r)

    def grp_h5(w):
        return (tau_pos + tau_neg)*((w**2)*tau_pos*tau_neg+1) / (((w**2)*(tau_pos**2)+1)*((w**2)*(tau_neg**2)+1))
    ax[8].plot(grid, np.unwrap(phase_h5(grid)))
    ax[8].set_title('phase spectrum for h5')
    ax[8].set_xscale('log')

    ax[9].plot(grid, grp_h5(grid))
    ax[9].set_title('group delay for h5')
    ax[9].set_xscale('log')

    plt.show()

def main():
    study_window_spectral_matching()
    # study_phase_spectra()

if __name__ == '__main__':
    main()
