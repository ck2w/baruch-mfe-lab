% script:  study_ema_on_px_series.m
% descrip: hw2 solutions that study an ema and ideal delay of a px series
% author:  JN Damask

clear

% import data
l_path = resolve_machine_path();
l_path = '/home/jaydamask/notes';
quotes = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_quotes.csv']);
trades = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_trades.csv']);

px_series = quotes.data(:,2);

%%
% ema

disp('ema of a px series')

Neff_v = [2 5 10 20 50 100];
Nwindow = 500;

% exec ema convolutions
for k = 1: length(Neff_v),
    Neff = Neff_v(k);
    h_ema = make_h_ema(Neff, Nwindow);
    h_ema_m(:,k) = h_ema;
    
    cand = conv(h_ema, px_series - px_series(1)) + px_series(1);
    y_ema(:,k) = cand(1: length(px_series));
end

% plots
subplot(211);
plot([0: Nwindow - 1], h_ema_m); grid on; title('impulse responses');

subplot(212);
stairs(px_series, 'k'); grid on; hold on
plot(y_ema); 
title('ema sequence of a px series')

%%
pause

%%
% ideal delay

disp('delay of a px series')

% exec ema convolutions
for k = 1: length(Neff_v),
    Neff = Neff_v(k);
    h_delta = make_h_delta(Neff, Nwindow);
    h_delta_m(:,k) = h_delta;
    
    cand = conv(h_delta, px_series - px_series(1)) + px_series(1);
    y_delay(:,k) = cand(1: length(px_series));
end

% plots
figure(2); clf
for k = 1: 2,
    ax(k) = subplot(2,1,k);
end
linkaxes(ax, 'x');

axes(ax(1));
stem([0: Nwindow - 1], h_delta_m); grid on; title('impulse responses');

axes(ax(2));
stairs(px_series, 'k'); grid on; hold on
plot(y_delay); 
title('delay sequence of a px series')


%%
pause

%%
% ema / delay comparison

disp('ema / delay comparisons')

Nv = length(Neff_v);

figure(3); clf

for k = 1: Nv,
   ax(k) = subplot(Nv/2,2,k);
end
%linkaxes(ax, 'x');

for k = 1: Nv,
   axes(ax(k));
   plot(h_ema_m(:,k)); grid on; hold on
   stem(h_delta_m(:,k), 'r'); 
   title(['Neff: ' num2str(Neff_v(k))])
   if k < Nv, set(ax(k), 'XTickLabel', []); end
end

figure(4); clf

for k = 1: Nv,
   ax(k) = subplot(Nv/2,2,k);
end
%linkaxes(ax, 'x');

for k = 1: Nv,
   axes(ax(k));
   plot(y_ema(:,k)); grid on; hold on
   plot(y_delay(:,k), 'r'); 
   ph = plot(px_series); set(ph, 'Color', 0.5 * [1 1 1]);
   title(['Neff: ' num2str(Neff_v(k))])
   if k < Nv, set(ax(k), 'XTickLabel', []); end
end










