% script: study_impulse_responses
% descrip: Plots all of the impulse response types for this homework on one plot
% author: JN Damask

% common defs
Nwindow = 400;
Neff_pos = 20;
Neff_neg = 40;
Nbox     = Neff_pos;

% representative impulse responses
h(:,1)  = make_h_unitstep(Nwindow);
h(:,2)  = make_h_box(Nbox, Nwindow);
h(:,3)  = make_h_delta(Neff_pos, Nwindow);
h(:,4)  = make_h_ema(Neff_pos, Nwindow);
h(:,5)  = make_h_macd(Neff_pos, Neff_neg, Nwindow);
h(:,6)  = make_h_macd_m1(Neff_pos, Neff_neg, Nwindow);

Nh = size(h,2);

% make a plot
figure(1); clf
for k = 1: Nh
   ax(k) = subplot(Nh,1,k); 
end
linkaxes(ax, 'x');

for k = 1: Nh,
   axes(ax(k));
   stem(h(:,k)); grid on
end


