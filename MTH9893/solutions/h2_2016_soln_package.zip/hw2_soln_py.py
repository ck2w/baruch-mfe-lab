__author__ = 'yifan'
# This script is for Math9893 at Baruch College
# This script refers to hw #2.
# Please uncomment each function in main() to test


import matplotlib.pyplot as plt
import math
import numpy as np
import pandas as pd

import utils

root_path = '/home/yifan/PycharmProjects'
quotes_path = root_path + '/Baruch/math9893/jpm_quotes.csv'
trades_path = root_path + '/Baruch/math9893/jpm_trades.csv'

quotes = pd.read_csv(quotes_path)
trades = pd.read_csv(trades_path)

def study_circular_convolution():
    '''
    hw2 solutions that studies circular convolution
    :return: None
    '''

    Nwindow = 256
    Neff = 32
    k = 192

    h_ema = utils.make_h_ema(Neff, Nwindow)
    h_impulse = utils.make_h_delta(k, Nwindow)

    fig1 = plt.figure()
    ax1 = fig1.add_subplot(211)
    ax1.set_xlim(0,Nwindow)
    ax1.grid(True)
    ax1.stem(h_impulse)
    ax2 = fig1.add_subplot(212, sharex=ax1)
    ax2.set_xlim(0,Nwindow)
    ax2.grid(True)
    ax2.plot(h_ema)

    # open convolution
    cond = np.convolve(h_ema, h_impulse)
    y_open = cond[:Nwindow]
    # circular convolution
    y_circ = utils.cconv(h_ema, h_impulse)

    fig2 = plt.figure()
    ax3 = fig2.add_subplot(111)
    ax3.set_xlim(0, Nwindow)
    ax3.grid(True)
    ax3.plot(y_open)
    ax3.plot(y_circ, color='red')

    plt.show()
    return None


def study_impulse_responses():
    '''
    Plots all of the impulse response types for this homework on plot
    :return: None
    '''

    Nwindow = 400
    Neff_pos = 20
    Neff_neg = 40
    Nbox = Neff_pos

    h = []
    h.append(utils.make_h_unitstep(Nwindow))
    h.append(utils.make_h_box(Nbox, Nwindow))
    h.append(utils.make_h_delta(Neff_pos, Nwindow))
    h.append(utils.make_h_ema(Neff_pos, Nwindow))
    h.append(utils.make_h_macd(Neff_pos, Neff_neg, Nwindow))
    h.append(utils.make_h_macd_m1(Neff_pos, Neff_neg, Nwindow))


    fig = plt.figure()
    ax = []
    for i in range(len(h)):
        ax.append(fig.add_subplot(len(h), 1, i+1))
        ax[-1].stem(h[i])

    plt.show()


def study_trade_series():
    '''
    Scripts that study impulse response with regard to a binned trade series.
    On a log-px series.
    :return: None
    '''
    vlm_series = trades['vlm']

    ##
    # a) ema

    print 'ema of binned trade-vlm series'

    Neff = 21
    Nwindow = 500
    h_ema = utils.make_h_ema(Neff, Nwindow)
    cand = np.convolve(h_ema, vlm_series - vlm_series[0]) + vlm_series[0]
    vlm_ema = cand[:len(vlm_series)]

    # b) compound smoothing

    print 'compound smoothing'

    Neff_pos = Neff / 3
    Neff_neg = 2 * Neff_pos

    # step 1
    h_u = utils.make_h_unitstep(len(vlm_series))

    cand = np.convolve(h_u, vlm_series - vlm_series[0]) + Nwindow * vlm_series[0]
    vlm_u = cand[:len(vlm_series)]

    # step 2
    gauge_macd = 1. / (Neff_neg - Neff_pos)
    fix = vlm_series[0] / sum(vlm_series)
    h_macd = utils.make_h_macd(Neff_pos, Neff_neg, Nwindow)

    cand = np.convolve(gauge_macd * h_macd, vlm_u - vlm_u[0]) + vlm_series[0]
    vlm_u_macd = cand[:len(vlm_u)]

    fig1 = plt.figure()
    ax1 = fig1.add_subplot(111)
    ax1.grid(True)
    ax1.plot(vlm_ema)
    ax1.plot(vlm_u_macd, color='red')
    ax1.set_title('Volume regularization')

    ##
    # compound impulse response

    cand = np.convolve(h_u, gauge_macd * h_macd)
    h_cmp = cand[:len(h_u)]

    cand = np.convolve(h_cmp, vlm_series - vlm_series[0]) + vlm_series[0]
    y_cmp = cand[:len(vlm_series)]

    fig2 = plt.figure()
    ax2 = fig2.add_subplot(111)
    ax2.grid(True)
    ax2.plot(h_ema)
    ax2.plot(h_cmp, color='red')
    ax2.set_title('Overlay of ema and compound impulse response')

    plt.show()


def study_conv_function():
    '''
    Scripts that study (in)correct application of the convolution function
    :return: None
    '''

    px_series = quotes['mid']

    ##
    # truncation

    print 'truncation'

    Neff = 20
    Nwindow = 5 * Neff
    h_ema = utils.make_h_ema(Neff, Nwindow)

    # a)
    cand = np.convolve(h_ema, px_series)

    print 'px_seris len: ', len(px_series)
    print 'h len: ', len(h_ema)
    print 'cand len: ', len(cand)

    # b)
    y = cand[:len(px_series)]
    print 'y len: ', len(y)

    fig1 = plt.figure()
    ax1 = fig1.add_subplot(211)
    ax1.step(range(len(px_series)), px_series)
    ax1.grid(True)
    ax1.plot(cand, color='red')
    ax2 = fig1.add_subplot(212, sharex=ax1)
    ax2.step(range(len(px_series)), px_series)
    ax2.grid(True)
    ax2.plot(y, color='red')

    ##
    # initialization

    print 'initialization'

    # a)
    cand = np.convolve(h_ema, px_series)
    y1 = cand[:len(px_series)]

    # b)
    cand = np.convolve(h_ema, px_series - px_series[0]) + px_series[0]
    y2 = cand[:len(px_series)]

    fig2 = plt.figure()
    ax1 = fig2.add_subplot(211)
    ax1.step(range(len(px_series)), px_series)
    ax1.grid(True)
    ax1.plot(y1, color='red')
    ax2 = fig2.add_subplot(212, sharex=ax1)
    ax2.step(range(len(px_series)), px_series)
    ax2.grid(True)
    ax2.plot(y2, color='red')

    # c)
    Neff_pos = 20
    Neff_neg = 40
    h_macd = utils.make_h_macd(Neff_pos, Neff_neg, Nwindow)

    cand = np.convolve(h_macd, px_series)
    y3 = cand[:len(px_series)]

    # d)
    cand = np.convolve(h_macd, px_series - px_series[0]) + px_series[0]
    y4 = cand[:len(px_series)]

    # e)
    cand = np.convolve(h_macd, px_series - px_series[0])
    y5 = cand[:len(px_series)]

    fig3 = plt.figure()
    for i, y in enumerate([y3, y4, y5]):
        ax = fig3.add_subplot(3,1,i+1)
        ax.grid(True)
        ax.plot(y)

    ##
    # gain

    print 'gain'

    # a)
    gain_v = [0.2, 1, 5]
    yg = []
    for k, g in enumerate(gain_v):
        cand = np.convolve(g * h_ema, px_series - px_series[0]) + g * px_series[0]
        yg.append(cand[:len(px_series)])

    fig4 = plt.figure()
    for k, y in enumerate(yg):
        ax = fig4.add_subplot(3,1,k+1)
        ax.grid(True)
        ax.step(range(len(px_series)), px_series)
        ax.plot(y, color='red')
        ax.set_title('gain: ' + str(gain_v[k]))

    # b)
    gain_v = [0.2, 1, 5]
    ym = []
    for k, g in enumerate(gain_v):
        cand = np.convolve(g * h_macd, px_series - px_series[0]) + g * px_series[0]
        ym.append(cand[:len(px_series)])

    fig5 = plt.figure()
    for k, y in enumerate(ym):
        ax = fig5.add_subplot(3,1,k+1)
        ax.grid(True)
        ax.plot(y)
        ax.set_title('gain: ' + str(gain_v[k]))

    plt.show()


def study_ema_on_px_series():
    '''
    Scripts that study an ema and ideal delay of a px series.
    :return: None
    '''

    px_series = quotes['mid']

    ##
    # ema

    print 'ema of a px series'

    Neff_v = [2, 5, 10, 20, 50, 100]
    Nwindow = 500

    # exec ema convolutions
    h_ema_m = []
    y_ema = []
    for k, Neff in enumerate(Neff_v):
        h_ema = utils.make_h_ema(Neff, Nwindow)
        h_ema_m.append(h_ema)

        cand = np.convolve(h_ema, px_series - px_series[0]) + px_series[0]
        y_ema.append(cand[:len(px_series)])

    fig1 = plt.figure()
    ax1 = fig1.add_subplot(211)
    ax1.grid(True)
    ax1.set_title('impulse response')
    for h_ema in h_ema_m:
        ax1.plot(h_ema)
    ax2 = fig1.add_subplot(212)
    ax2.grid(True)
    ax2.set_title('ema sequence of a px series')
    ax2.step(range(len(px_series)), px_series)
    for y in y_ema:
        ax2.plot(y)

    ##
    # ideal delay

    print 'delay of a px series'

    # exec ema convolutions
    h_delta_m = []
    y_delay = []
    for k, Neff in enumerate(Neff_v):
        h_delta = utils.make_h_delta(Neff, Nwindow)
        h_delta_m.append(h_delta)

        cand = np.convolve(h_delta, px_series - px_series[0]) + px_series[0]
        y_delay.append(cand[:len(px_series)])

    fig2 = plt.figure()
    ax1 = fig2.add_subplot(211)
    ax1.grid(True)
    ax1.set_title('impulse response')
    for h_delta in h_delta_m:
        ax1.stem(h_delta)
    ax2 = fig2.add_subplot(212)
    ax2.grid(True)
    ax2.set_title('delay sequence of a px series')
    ax2.step(range(len(px_series)), px_series)
    for y in y_delay:
        ax2.plot(y)

    ##
    # ema / delay comparison

    print 'ema / delay comparison'

    fig3 = plt.figure()
    for k in range(len(Neff_v)):
        ax = fig3.add_subplot(len(Neff_v)/2, 2, k+1)
        ax.plot(h_ema_m[k], color='red')
        ax.stem(h_delta_m[k])
        ax.set_title('Neff: ' + str(Neff_v[k]))

    fig4 = plt.figure()
    for k in range(len(Neff_v)):
        ax = fig4.add_subplot(len(Neff_v)/2, 2, k+1)
        ax.plot(y_ema[k])
        ax.plot(y_delay[k], color='red')
        ax.plot(px_series, color='green')
        ax.set_title('Neff: ' + str(Neff_v[k]))

    plt.show()


def study_macd_on_log_px_series():
    '''
    Scripts that study an macd, its first-moment surrogate
    :return: None
    '''

    px_series = quotes['mid']

    ##
    # a) macd-m1

    print 'macd-m1 of a log-px series'

    Neff_pos_v = [2, 5, 10, 20, 50]
    Nwindow = 500

    # exec ema convolutions
    h_macd_m1_m = []
    y_macd_m1 = []
    for k, Neff_pos in enumerate(Neff_pos_v):
        Neff_neg = 2 * Neff_pos
        h_macd_m1 = utils.make_h_macd_m1(Neff_pos, Neff_neg, Nwindow)
        h_macd_m1_m.append(h_macd_m1)

        cand = np.convolve(h_macd_m1, np.log(px_series) - np.log(px_series[0]))
        y_macd_m1.append(cand[:len(px_series)])

    ##
    # b)

    print 'macd of a log-px series'

    # exec ema convolutions
    h_macd_m = []
    y_macd = []
    for k, Neff_pos in enumerate(Neff_pos_v):
        Neff_neg = 2 * Neff_pos
        h_macd = utils.make_h_macd(Neff_pos, Neff_neg, Nwindow)
        h_macd_m.append(h_macd)

        cand = np.convolve(h_macd, np.log(px_series) - np.log(px_series[0]))
        y_macd.append(cand[:len(px_series)])

    ##
    # comparison plots

    # impulse response
    fig1 = plt.figure()
    for k in range(len(Neff_pos_v)):
        ax = fig1.add_subplot(math.ceil(len(Neff_pos_v)/2.), 2, k+1)
        ax.grid(True)
        ax.stem(h_macd_m1_m[k])
        ax.plot(h_macd_m[k], color='red')

    # since this plot does not reveal too much, we will replot it this way

    fig2 = plt.figure()
    for k in range(len(Neff_pos_v)):
        ax = fig2.add_subplot(math.ceil(len(Neff_pos_v)/2.), 2, k+1)
        ax.grid(True)
        ax.plot(h_macd_m[k])
        ax.plot(Neff_pos_v[k], h_macd_m[k][Neff_pos_v[k]], 'ro')
        ax.plot(2*Neff_pos_v[k], h_macd_m[k][2*Neff_pos_v[k]], 'ro')

    # output series
    fig3 = plt.figure()
    for k in range(len(Neff_pos_v)):
        ax = fig3.add_subplot(math.ceil(len(Neff_pos_v)/2.), 2, k+1)
        ax.grid(True)
        ax.plot(y_macd_m1[k])
        ax.plot(y_macd[k], color='red')

    plt.show()


def study_quote_trade_data():
    '''
    Plots the quote and trade data on the same x-axis scale
    :return: None
    '''

    vlm_series = trades['vlm']
    px_series = quotes['mid']

    fig = plt.figure()

    ax1 = fig.add_subplot(2, 1, 1)
    ax1.step(range(len(px_series)), px_series)
    ax1.grid(True)
    ax1.set_title('px series')

    ax2 = fig.add_subplot(2, 1, 2)
    ax2.step(range(len(px_series)), vlm_series)
    ax2.grid(True)
    ax2.set_title('volume series')

    plt.show()


def main():
    # study_circular_convolution()
    # study_impulse_responses()
    # study_trade_series()
    # study_conv_function()
    # study_ema_on_px_series()
    # study_macd_on_log_px_series()
    study_quote_trade_data()


if __name__ == '__main__':
    main()
