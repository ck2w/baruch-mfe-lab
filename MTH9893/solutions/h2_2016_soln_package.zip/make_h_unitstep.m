function h = make_h_unitstep(Nwindow)

% descrip: returns a truncated unit-step response
% author: JN Damask

h = ones(Nwindow, 1);



