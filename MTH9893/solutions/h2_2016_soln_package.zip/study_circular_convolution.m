% script:  study_circular_convolution.m
% descrip: hw2 solutions that studies circular convolution.
% author:  JN Damask

clear

% impulse responses
Nwindow = 256;
Neff = 32;
k = 192;

h_ema     = make_h_ema(Neff, Nwindow);
h_impulse = make_h_delta(k, Nwindow);

figure(1); clf
for i=1:2, ax(i) = subplot(2,1,i); end
linkaxes(ax, 'x');
axes(ax(1))
stem(h_impulse); grid on

axes(ax(2))
plot(h_ema); grid on

% open convolution
cand = conv(h_ema, h_impulse);
y_open = cand(1: Nwindow);

% circ convolution
y_circ = cconv(h_ema, h_impulse);


% plot comparison
figure(2); clf;
plot(y_open); grid on; hold on
plot(y_circ, 'r--');


