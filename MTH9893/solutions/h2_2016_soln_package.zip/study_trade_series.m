% script:  study_trade_series.m
% descrip: hw2 solutions that study impulse response with regard to a binned
%          trade series.
%          on a log-px series.
% author:  JN Damask

clear

% import data
l_path = resolve_machine_path();
quotes = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_quotes.csv']);
trades = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_trades.csv']);

vlm_series = trades.data(:,5);

%%
% a) ema

disp('ema of binned trade-vlm series');

Neff = 21;
Nwindow = 500;
h_ema = make_h_ema(Neff, Nwindow);

cand = conv(h_ema, vlm_series - vlm_series(1)) + vlm_series(1);
vlm_ema = cand(1: length(vlm_series));

% b) compound smoothing

disp('compound smoothing');

Neff_pos = Neff / 3;  
Neff_neg = 2 * Neff_pos;

%   step 1
h_u = make_h_unitstep(length(vlm_series));

cand = conv(h_u, vlm_series - vlm_series(1)) + Nwindow * vlm_series(1);
vlm_u = cand(1: length(vlm_series));

%   step 2
gauge_macd = 1 / (Neff_neg - Neff_pos);
fix = vlm_series(1) / sum(vlm_series);
h_macd = make_h_macd(Neff_pos, Neff_neg, Nwindow);

cand = conv(gauge_macd * h_macd, vlm_u - vlm_u(1)) + vlm_series(1);
vlm_u_macd = cand(1: length(vlm_u));

% make a plot
figure(1); clf
plot(vlm_ema); grid on; hold on;
plot(vlm_u_macd, 'r');
title('Volume regularization');


%%
% compound impulse response

cand = conv(h_u, gauge_macd * h_macd);
h_cmp = cand(1: length(h_u));

cand = conv(h_cmp, vlm_series - vlm_series(1)) + vlm_series(1);
y_cmp = cand(1: length(vlm_series));

% make a plot
figure(2); clf
plot(h_ema); grid on; hold on
plot(h_cmp, 'r');
title('Overlay of ema and compound impulse response');












