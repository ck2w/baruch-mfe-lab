% script:  study_conv_function.m
% descrip: hw2 solutions that study (in)correct application of the convolution function.
% author:  JN Damask

clear

% import data
l_path = resolve_machine_path();
quotes = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_quotes.csv']);
trades = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_trades.csv']);

px_series = quotes.data(:,2);

%%
% truncation

disp('truncation');

Neff = 20;
Nwindow = 5 * Neff;
h_ema = make_h_ema(Neff, Nwindow);

% a)
cand = conv(h_ema, px_series);

disp(['px_series len:' num2str(length(px_series)) ...
    ' h len:' num2str(length(h_ema)) ' cand len:' num2str(length(cand))]);

% b)
y = cand(1: length(px_series));

disp(['px_series len:' num2str(length(px_series)) ...
    ' h len:' num2str(length(h_ema)) ' y len:' num2str(length(y))]);

% plots
figure(1); clf
for k = 1: 2, ax(k) = subplot(2,1,k); end; linkaxes(ax, 'x');

axes(ax(1));
stairs(px_series); grid on; hold on
plot(cand, 'r');

axes(ax(2));
stairs(px_series); grid on; hold on
plot(y, 'r'); 
xlim([0 500])

%%
pause

%% 
% initialization

disp('initialization');

% a)
cand = conv(h_ema, px_series);
y1 = cand(1: length(px_series));

% b)
cand = conv(h_ema, px_series - px_series(1)) + px_series(1);
y2 = cand(1: length(px_series));

% plots
figure(2); clf

for k = 1: 2, ax(k) = subplot(2,1,k); end; linkaxes(ax, 'x');

axes(ax(1));
stairs(px_series); grid on; hold on
plot(y1, 'r');

axes(ax(2));
stairs(px_series); grid on; hold on
plot(y2, 'r'); 

% c)
Neff_pos = 20; 
Neff_neg = 40;
h_macd = make_h_macd(Neff_pos, Neff_neg, Nwindow);

cand = conv(h_macd, px_series);
y3 = cand(1: length(px_series));

% d)
cand = conv(h_macd, px_series - px_series(1)) + px_series(1);
y4 = cand(1: length(px_series));

% e)
cand = conv(h_macd, px_series - px_series(1));
y5 = cand(1: length(px_series));

% plots
figure(3); clf

for k = 1: 3, ax(k) = subplot(3,1,k); end; linkaxes(ax, 'x');

axes(ax(1));
plot(y3); grid on

axes(ax(2));
plot(y4); grid on

axes(ax(3));
plot(y5); grid on

%%
pause

%%
% gain

disp('gain');

% a)
gain_v = [0.2 1 5];
for k = 1: length(gain_v),
   g = gain_v(k);
   
   cand = conv(g * h_ema, px_series - px_series(1)) + g * px_series(1);
   yg(:,k) = cand(1: length(px_series));
    
end

% plots
figure(4); clf
for k = 1: 3, ax(k) = subplot(3,1,k); end; linkaxes(ax, 'x');

for k = 1: 3, 
    axes(ax(k))
    stairs(px_series); grid on; hold on
    plot(yg(:,k), 'r');
    title(['gain: ' num2str(gain_v(k))]);
end

% b)
gain_v = [0.2 1 5];
for k = 1: length(gain_v),
   g = gain_v(k);
   
   cand = conv(g * h_macd, px_series - px_series(1)) + g * px_series(1);
   ym(:,k) = cand(1: length(px_series));
    
end

% plots
figure(5); clf
for k = 1: 3, ax(k) = subplot(3,1,k); end; linkaxes(ax, 'x');

for k = 1: 3, 
    axes(ax(k))
    plot(ym(:,k)); grid on
    title(['gain: ' num2str(gain_v(k))]);
end








