function h = make_h_macd_m1(Neff_pos, Neff_neg, Nwindow)

% descrip: returns a first-moment representation of an macd response
% author: JN Damask

h_pos = make_h_delta(Neff_pos, Nwindow);
h_neg = make_h_delta(Neff_neg, Nwindow);

h = h_pos - h_neg;

