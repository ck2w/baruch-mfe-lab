% script:  study_quote_trade_data.m
% descrip: loads and plots the quote and trade data on the same x-axis scale
% author:  JN Damask

clear

% import data
l_path = resolve_machine_path();
quotes = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_quotes.csv']);
trades = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_trades.csv']);

% make common axes
figure(1); clf
for k = 1: 2, 
    ax(k) = subplot(2,1,k);
end
linkaxes(ax, 'x');

% make plots
axes(ax(1))
stairs(quotes.data(:,2)); grid on

axes(ax(2))
stairs(trades.data(:,5)); grid on





