__author__ = 'yifan'
# This script is for Math9893 at Baruch College


import numpy as np


def make_h_box(Nbox, Nwindow):
    '''
   Returns a box-averager impulse response

    :param Nbox:
    :param Nwindow:
    :return: box-averager impulse response
    '''

    h = np.concatenate((1. / Nbox * np.ones(Nbox), np.zeros(Nwindow - Nbox)))
    return h


def make_h_delta(k, Nwindow):
    '''
    Returns a ideal delay

    :param k:
    :param Nwindow:
    :return: a ideal delay
    '''
    h = np.zeros(Nwindow)
    h[k-1] = 1.
    return h


def make_h_ema(Neff, Nwindow):
    '''
    Return a truncated ema impulse response. Due to the truncation
    the gain is less than unity.

    :param Neff:
    :param Nwindow:
    :return: truncated ema impulse response
    '''

    p = Neff / (Neff + 1.)
    n = np.array(range(Nwindow))
    h = (1. - p) * (p ** n)
    return h


def make_h_macd(Neff_pos, Neff_neg, Nwindow):
    '''
    Returns a truncated macd response

    :param Neff_pos:
    :param Neff_neg:
    :param Nwindow:
    :return: truncated macd response
    '''

    h_pos = make_h_ema(Neff_pos, Nwindow)
    h_neg = make_h_ema(Neff_neg, Nwindow)
    h = h_pos - h_neg
    return h


def make_h_macd_m1(Neff_pos, Neff_neg, Nwindow):
    '''
    Returns a first-moment representation of an macd response.

    :param Neff_pos:
    :param Neff_neg:
    :param Nwindow:
    :return: first-moment representation of an macd response
    '''

    h_pos = make_h_delta(Neff_pos, Nwindow)
    h_neg = make_h_delta(Neff_neg, Nwindow)
    h = h_pos - h_neg
    return h


def make_h_unitstep(Nwindow):
    '''
    Returns a truncated unit-step response

    :param Nwindow:
    :return: truncated unit-step response
    '''

    h = np.ones(Nwindow)
    return h


def cconv(a, b):
    '''
    Return circular convolution of two real value array
    :param a:
    :param b:
    :return:
    '''

    a = np.asarray(a)
    b = np.asarray(b)

    return np.fft.ifft(np.fft.fft(a) * np.fft.fft(b)).real

def main():
    pass


if __name__ == '__main__':
    main()
