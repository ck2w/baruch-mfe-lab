% script:  study_macd_on_log_px_series.m
% descrip: hw2 solutions that study an macd, its first-moment surrogate,
%          on a log-px series.
% author:  JN Damask

clear

% import data
l_path = resolve_machine_path();
quotes = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_quotes.csv']);
trades = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_trades.csv']);

px_series = quotes.data(:,2);

%%
% a) macd-m1

disp('macd-m1 of a log-px series')

Neff_pos_v = [2 5 10 20 50];
Nwindow = 500;

% exec ema convolutions
for k = 1: length(Neff_pos_v),
    Neff_pos = Neff_pos_v(k);
    Neff_neg = 2 * Neff_pos;
    h_macd_m1 = make_h_macd_m1(Neff_pos, Neff_neg, Nwindow);
    h_macd_m1_m(:,k) = h_macd_m1;
    
    cand = conv(h_macd_m1, log(px_series) - log(px_series(1)));
    y_macd_m1(:,k) = cand(1: length(px_series));
end


%%
% b) macd

disp('macd of a log-px series')

% exec ema convolutions
for k = 1: length(Neff_pos_v),
    Neff_pos = Neff_pos_v(k);
    Neff_neg = 2 * Neff_pos;
    h_macd = make_h_macd(Neff_pos, Neff_neg, Nwindow);
    h_macd_m(:,k) = h_macd;
    
    cand = conv(h_macd, log(px_series) - log(px_series(1)));
    y_macd(:,k) = cand(1: length(px_series));
end

%%
% comparison plots

% impulse responses
figure(1); clf
Nv = length(Neff_pos_v);
for k = 1: Nv,
    ax(k) = subplot(ceil(Nv/2), 2, k);
end
linkaxes(ax, 'x');

for k = 1: Nv,
   axes(ax(k));
   stem(h_macd_m1_m(:,k)); grid on; hold on
   plot(h_macd_m(:,k), 'r');
   if k < Nv, set(ax(k), 'XTickLabel', []); end
end

% note: since this plot doesn't reveal too much, then I'll replot it this way...

figure(2); clf
Nv = length(Neff_pos_v);
for k = 1: Nv,
    ax(k) = subplot(ceil(Nv/2), 2, k);
end
linkaxes(ax, 'x');

for k = 1: Nv,
    axes(ax(k));
   plot(h_macd_m(:,k)); grid on; hold on
   plot(Neff_pos_v(k), h_macd_m(Neff_pos_v(k),k), 'ro');
   plot(2*Neff_pos_v(k), h_macd_m(2*Neff_pos_v(k),k), 'ro');
   if k < Nv, set(ax(k), 'XTickLabel', []); end
end


% output series
figure(3); clf
Nv = length(Neff_pos_v);
for k = 1: Nv,
    ax(k) = subplot(ceil(Nv/2), 2, k);
end
linkaxes(ax);

for k = 1: Nv,
    axes(ax(k));
   plot(y_macd_m1(:,k)); grid on; hold on
   plot(y_macd(:,k), 'r');
   if k < Nv, set(ax(k), 'XTickLabel', []); end
end














