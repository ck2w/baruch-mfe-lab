__author__ = 'yifan'
# This script is for Math9893 at Baruch College
# This script refers to hw #5
# Please uncomment each function in main() to test


import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import utils_hw5

root_path = '/home/yifan/PycharmProjects'
quotes_path = root_path + '/Baruch/math9893/jpm_quotes.csv'

quotes = pd.read_csv(quotes_path)
px_series = quotes['mid']

fns = ['delay', 'unitstep', 'box', 'ema', 'ema_poly1', 'lifted_macd', 'macd']

# lags of output used in recursion
lags_y = {'delay': 0,
          'unitstep': 0,
          'box': 1,
          'ema': 1,
          'ema_poly1': 2,
          'lifted_macd': 3,
          'macd': 2}

No = 32
Nwindow = 8 * No

# impulse-response parameters
h_param = {'delay': {'Ndelay': No},
           'box': {'Nbox': No},
           'ema': {'Neff': No},
           'ema_poly1': {'Neff': No},
           'lifted_macd': {'Neff_lift': No},
           'macd': {'Neff_pos': No/2, 'Neff_neg': No}
           }

# associated fed's as lambda functions
fde = {'delay': lambda x: utils_hw5.apply_delay_filter(x, h_param['delay']['Ndelay']),
       'unitstep': lambda x: utils_hw5.apply_unit_step_filter(x),
       'box': lambda x: utils_hw5.apply_box_filter(x, h_param['box']['Nbox']),
       'ema': lambda x: utils_hw5.apply_ema_filter(x, h_param['ema']['Neff']),
       'ema_poly1': lambda x: utils_hw5.apply_ema_poly1_filter(x, h_param['ema_poly1']['Neff']),
       'lifted_macd': lambda x: utils_hw5.apply_lifted_macd_filter(x, h_param['lifted_macd']['Neff_lift']),
       'macd': lambda x: utils_hw5.apply_macd_filter(x, h_param['macd']['Neff_pos'], h_param['macd']['Neff_neg'])
       }

# compute equivalent h[n]'s
h = {'delay': utils_hw5.make_h_delta(h_param['delay']['Ndelay'], Nwindow),
     'box': utils_hw5.make_h_box(h_param['box']['Nbox'], Nwindow),
     'ema': utils_hw5.make_h_ema(h_param['ema']['Neff'], Nwindow),
     'ema_poly1': utils_hw5.make_h_ema_poly1(h_param['ema_poly1']['Neff'], Nwindow),
     'lifted_macd': utils_hw5.make_h_lifted_macd_poly(h_param['lifted_macd']['Neff_lift'] * 24. / 23., Nwindow),
     'macd': utils_hw5.make_h_macd(h_param['macd']['Neff_pos'], h_param['macd']['Neff_neg'], Nwindow)
     }


def study_fde_impulse_response():
    '''
    Applies an impulse to each fde, measures the impulse response, and compares
    that response with the original h[n] equation
    :filters:
            delay
            unit step
            box
            ema
            ema-poly1
            lifted-macd
            macd
    :return:
    '''

    # iterate through fde's, generate an impulse input with lags_y + 1 delay,
    # compute the fde impulse response, compute the associated h[n] response,
    # plot in overlay.

    n = np.array(range(Nwindow))
    print 'size n: ', len(n)

    h_fde = {}
    gain_fde = {}
    M1_fde = {}
    h_n = {}

    # compute the equivalent h[n]'s for unit step
    h['unitstep'] = utils_hw5.make_h_unitstep(Nwindow)

    # figures
    figs = [plt.figure() for i in range(len(fns))]

    for i, fn in enumerate(fns):
        print fn

        # make an impulse input with unity at lags_y + 1
        impulse = np.zeros(Nwindow + lags_y[fn])
        impulse[lags_y[fn]] = 1

        # compute the fde impulse response
        cand = fde[fn](impulse)
        h_fde[fn] = cand[lags_y[fn]:]

        # explicitly compute gain and M1
        gain_fde[fn] = np.sum(h_fde[fn])
        M1_fde[fn] = np.sum(n * h_fde[fn])

        # compute h[n]
        h_n[fn] = h[fn]

        # plot the response
        ax = figs[i].add_subplot(111)
        ax.grid(True)
        ax.plot(h_fde[fn])
        ax.plot(h_n[fn], 'r')
        ax.set_title('Filter: '+fn)

    plt.show()
    print gain_fde
    print M1_fde


def study_fde_application():
    '''
    Applies an price series to each fde, and compares
    that response with the one created by convolution
    :filters:
            delay
            unit step
            box
            ema
            ema-poly1
            lifted-macd
            macd
    :return:
    '''

    # iterate through fde's, compute the filtered price series, compute the associated ones with convolution,
    # plot in overlay.

    n = np.array(range(len(px_series)))
    print 'size n: ', len(n)

    y_fde = {}
    y_n = {}

    # compute the equivalent h[n]'s for unit step
    h['unitstep'] = utils_hw5.make_h_unitstep(len(px_series))

    # figures
    figs = [plt.figure() for i in range(len(fns))]

    for i, fn in enumerate(fns):
        print fn

        y_fde[fn] = fde[fn](px_series)

        # check if this case needs subtract and then add back the first element
        if fn in ['delay', 'unitstep']:
            subtract_coeff = 0
            add_coeff = 0
        elif fn in ['box', 'ema', 'ema_poly1', 'lifted_macd']:
            subtract_coeff = 1
            add_coeff = 1
        else: # the 'macd' case
            subtract_coeff = 1
            add_coeff = 0

        # compute the fde impulse response
        cand = np.convolve(h[fn], px_series - subtract_coeff * px_series[0]) + add_coeff * px_series[0]
        y_n[fn] = cand[:len(px_series)]

        # plot the response
        ax = figs[i].add_subplot(111)
        ax.grid(True)
        ax.plot(y_fde[fn])
        ax.plot(y_n[fn], 'r.')
        ax.set_title('Filter: '+fn)

    plt.show()


def main():

    study_fde_impulse_response()
    # study_fde_application()


if __name__ == '__main__':
    main()