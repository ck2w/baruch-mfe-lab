% script:  study_intensity_weighted_ema.m
% descrip: Uses an AB-ema to compute an intensity-weighted price ema. 

% import data
l_path = resolve_machine_path();
quotes = importdata([l_path '/data/homework_solutions/2012/hw2/jpm_quotes.csv']);

px_series       = quotes.data(:,2);
quote_intensity = quotes.data(:,3);

% static ema specification
Neff = 32;

% compute emas
[ema_px, ema_ints, ema_px_star, Neff_star] = compute_ab_ema(Neff, px_series, quote_intensity);

% make some plots

% figure(10); clf
% for k=1:2, ax(k) = subplot(2,1,k); end; linkaxes(ax, 'x');
% axes(ax(1))
% stairs(px_series); grid on; hold on
% axes(ax(2))
% stairs(quote_intensity); grid on; hold on
% 
% disp('hit any key')
% pause
% 
% axes(ax(1))
% plot(ema_px, 'r');
% 
% break

figure(11); clf
subplot(211)
stairs(Neff_star); grid on; 
title('quote Neff*');

subplot(212);
cdfplot(Neff_star); grid on
title('cdf of quote Neff*');

figure(11); clf
for k=1:3, ax(k) = subplot(3,1,k); end; linkaxes(ax, 'x')

axes(ax(1)); 
stairs(px_series); 
grid on; hold on
plot(ema_px, 'r');
plot(ema_px_star, 'k');
title('Price series, ema and intensity-adjusted ema')

axes(ax(2));
stairs(quote_intensity); 
grid on; 
title('Intensity profile')

axes(ax(3));
stairs(Neff_star); grid on
title('quote Neff*');

figure(21); clf
cdfplot(Neff_star); grid on
title('CDF of Neff-star')

figure(31);
plot(quote_intensity(2:end), Neff_star, 'b.'); grid on
xlabel('quote intensity')
ylabel('Neff-star')
title('Correspondence of quote-intensty level to Neff-star')







