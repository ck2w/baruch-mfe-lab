function [ema_a, ema_b, ema_a_star, Neff_star] = compute_ab_ema(Neff, a_series, b_series)

% script: Computes 
%
%  ema(A*) = ema(A B) / ema(B)

% init
n = [0: 10 * Neff];
d = Neff / (Neff + 1);
h = (1-d) * d.^n;

% ema_b
cand = conv(h, b_series - b_series(1)) + b_series(1);
ema_b = cand(1: length(b_series));
d_star = d * ema_b(1:end-1) ./ ema_b(2:end);
Neff_star = d_star ./ (1 - d_star);

% ema_a
cand = conv(h, a_series - a_series(1)) + a_series(1);
ema_a = cand(1: length(a_series));

% ema_ab
ab_series = a_series .* b_series;
cand = conv(h, ab_series - ab_series(1)) + ab_series(1);
ema_ab = cand(1: length(ab_series));

% ema_a_star
ema_a_star = ema_ab ./ ema_b;





