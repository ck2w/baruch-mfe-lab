% script:  study_tsay_fdes.m
% descrip: 

%% 
% AR(3) eq (2.15) pg 38
%
% r[n] = 0.0047 + 0.35 r[n-1] + 0.18 r[n-2] - 0.14 r[n-3] + e[n]
%
% break into two parts:
%
% Q(z) R(z) = c / (1 - z-inv)  ---->  Qi(z) R(z) = c
%
% Q(z) R(z) = P(z) E(z)    P(z) = 1
%
%
% Together:
% 
%  R(z) = c / Qi(z) + E(z) / Q(z)
%

% -- AR(3) specification

% Q(z) specification in z-inv
c = 0.0047;
Qz  = [0.14 -0.18 -0.35 1];  % note this is a polynomial in z-inv

% Matlab needs polynomials in z
mw_Qz = fliplr(Qz);

% -- Convert to impulse response
n = [-3: 20]';

% find poles and residues
[E_invQz.residues  E_invQz.poles  E_invQz.direct]  = residue([1 0 0 0], mw_Qz);

% impulse response
h = zeros(size(n));
for k = 1: length(E_invQz.residues),
   h = h + E_invQz.residues(k) * E_invQz.poles(k).^n; 
end

cand = conv(h, ones(size(n)));
h_ic = cand(1: length(n));

h_ar3 = h + c * h_ic;

% -- Gain, analytic and numeric
gain_analytic = 1 / sum(Qz);
gain_numeric = sum(h);

% -- Run recursion, compute impulse response
lags_y = 3;
xn = [zeros(lags_y,1); zeros(length(n),1)];
xn(lags_y+1) = 1;
yn = zeros(size(xn));
yn(1:3) = 0.0;

% run recursion
for k = lags_y + 1: length(yn),
    
   yn(k) = 0.0047 + 0.35 * yn(k-1) + 0.18 * yn(k-2) - 0.14 * yn(k-3) + xn(k);
    
end

y = yn(2: end);

% -- Plots
% impulse response, analytic and computed
figure(1); clf
plot(n, h_ar3, 'b'); 
grid on; hold on

plot(n, y(1:length(n)), 'r')
title('blue: analytic response, red: fde response');

% -- Pole / Zero diagrams
figure(2); clf
for k = 1: length(E_invQz.poles),
   
    plot(real(E_invQz.poles(k)), imag(E_invQz.poles(k)), 'rx');
    hold on
    
end
plot(0,0, 'bo'); 
plot(cos([-1:0.01:1] * pi), sin([-1:0.01:1] * pi), 'k'); 
grid on; axis equal




