__author__ = 'yifan'
# This script is for Math9893 at Baruch College
# This script refers to hw #6
# Please uncomment each function in main() to test


import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
from scipy import signal

def study_tsay_fdes():
    '''
     AR(3) eq (2.15) pg 38

     r[n] = 0.0047 + 0.35 r[n-1] + 0.18 r[n-2] - 0.14 r[n-3] + e[n]

     break into two parts:

     Q(z) R(z) = c / (1 - z-inv)  ---->  Qi(z) R(z) = c

     Q(z) R(z) = P(z) E(z)    P(z) = 1


     Together:

      R(z) = c / Qi(z) + E(z) / Q(z)

    :return:
    '''

    # -- AR(3) specification

    # Q(z) specification in z-inv
    c = 0.0047
    Qz = [0.14, -0.18, -0.35, 1.0] # note this is a polynomial in z-inv

    # scipy needs polynomial in z
    Qz.reverse()

    # -- Convert to impulse response
    n = np.array(range(-3, 21))

    residues, poles, direct = signal.residue([1, 0, 0, 0], Qz)

    # impulse response
    h = np.zeros(len(n))

    for k in range(len(residues)):
        h = h + residues[k] * poles[k] ** n

    cand = sp.convolve(h, np.ones(len(n)))
    h_ic = cand[:len(n)]

    h_ar3 = h + c * h_ic

    # -- Gain, analytic and numeric
    gain_analytic = 1. / sum(Qz)
    gain_numeric = sum(h)

    # -- Run recursion, compute impulse response
    lags_y = 3
    xn = np.zeros(lags_y + len(n))
    xn[lags_y] = 1.
    yn = np.zeros(len(xn))
    yn[:3] = 0.0

    # run recursion
    for k in range(lags_y, len(yn)):
        yn[k] = 0.0047 + 0.35*yn[k-1] + 0.18*yn[k-2] - 0.14*yn[k-3] + xn[k]

    y = yn[1:]

    # -- Plots
    # impulse response, analytic and computed
    fig1 = plt.figure()
    ax = fig1.add_subplot(111)
    ax.grid(True)
    ax.plot(n, h_ar3, 'b')
    ax.plot(n, y[:len(n)], 'r')
    ax.set_title('blue: analytic response, red: fde response')

    # -- Pole / Zero diagrams
    fig2 = plt.figure()
    ax = fig2.add_subplot(111)
    for k in range(len(poles)):
        ax.plot(np.real(poles[k]), np.imag(poles[k]), 'rx')
    ax.plot(0, 0, 'bo')
    ax.plot(np.cos(np.linspace(-1, 1, 201) * np.pi), np.sin(np.linspace(-1, 1, 201) * np.pi), 'k')
    ax.grid(True)
    ax.axis('equal')

    plt.show()


def main():
    study_tsay_fdes()

if __name__ == '__main__':
    main()
