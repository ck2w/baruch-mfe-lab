function moments = compute_moments_of_hn(hn)

%--------------------------------------------------------------------------------------------------
%
% fcxn:    compute_moments_of_hn.m
% descrip: computes the sample moments of impulse response hn.
% domain:  discrete
% note:    The moments are
%            M0 = sum( hn )
%            M1 = sum( naxis * hn )
%            M2 = sum( naxis^2 * hn )
%            RHW = sqrt( M2 / M1^2 - 1 )
%        
% inputs:  /hn/       an impulse response
% output:  /moments/  a structure with the moment results
%
% author:  JN Damask
%
%--------------------------------------------------------------------------------------------------

% infer naxis from the length of hn
hn      = hn(:);
Nwindow = length(hn);
naxis   = [0: Nwindow-1]';

% gain -- zeroth moment
moments.M0 = sum( hn );

% normalize hn to M0
hn_norm = hn / moments.M0;

% 1st and 2nd order moments
moments.M1 = naxis' * hn_norm;
moments.M2 = (naxis .* naxis)' * hn_norm;

% relative half width
moments.rhw = sqrt( moments.M2 / moments.M1^2 - 1 );



