%--------------------------------------------------------------------------------------------------
%
% script:  illustrate_polyema_impulse_response_and_sacf.m
% descrip: Given the homework transfer function for the polyema,
%
%            Hm(z) = (1 - p/m)^m / (1 - p/m z^-1)^m,
%
%          this script plots the impulse responses and system
%          autocorrelation functions. 
% 
% author:  JN Damask
%
%--------------------------------------------------------------------------------------------------

% defs
M1 = 50;
mv      = [1: 5]';
Nm      = length(mv);
sacf_thresh = 0.05;  %  5%

% axes
Nwindow = 1000;
naxis   = [0: Nwindow-1]';

Nsacf   = 2 * Nwindow - 1;
saxis   = [-Nwindow+1: Nwindow-1]'; 

% matrices for plots
hnm     = zeros(Nwindow, Nm);
hnm_fde = zeros(size(hnm));
sacfm   = zeros(Nsacf, Nm);



% iter over orders
for k = 1: Nm,
    
    % compute the impulse response
    m        = mv(k);
    hnm(:,k) = make_h_polyema_dt_hw(M1, m, Nwindow);
    
    % compute moments
    moments{k} = compute_moments_of_hn(hnm(:,k));
    
    % compute analytic moments
    moments{k}.rhw_analytic = sqrt( 1 / m + 1 / moments{k}.M1 );
    
    % compute system acf
    profile{k} = compute_sacf_of_hn(hnm(:,k), sacf_thresh);
    
    % compute sacf width / M1
    profile{k}.sacf_width_norm = profile{k}.sacf_width / moments{k}.M1;
    
    % store in a convenient matrix
    sacfm(:,k) = profile{k}.sacf_norm;
    
    % compute impulse response from fde
    hnm_fde(:,k) = compute_fde_polyema_impulse_response(M1, m, Nwindow);
    
end
    

%-------------------------------------------------------------------------------------
% plots

% impules responses
figure(1); clf
plot(naxis, hnm); grid on
title('impulse responsees')

% sys-acfs raw
figure(2); clf
sacf_axis = profile{1}.sacf_axis;

hold on
for k = 1: Nm,
    plot(sacf_axis, profile{k}.sacf_norm);
end
title('raw system acfs')

% sys-acfs normalized by M1
figure(3); clf

hold on
for k = 1: Nm,
   
    M1 = moments{k}.M1;
    plot(sacf_axis / M1, profile{k}.sacf_norm);
    
end
hold on
plot([0 5], [1 1] * sacf_thresh, 'r');

title('system acfs with width normalized by M1');
xlim([0 5]); grid on

% hn overlay from h[n] and fde
order = 1;
for ifig = 4: 8,
   
    figure(ifig); clf
    plot(naxis, hnm(:,order)); hold on
    plot(naxis, hnm_fde(:,order), 'r.'); 
    
    order = order + 1;
    
end












