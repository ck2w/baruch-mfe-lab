function profile = compute_sacf_of_hn(hn, thresh)

%--------------------------------------------------------------------------------------------------
%
% fcxn:    compute_sacf_of_hn.m
% descrip: computes the sample system autocorrelation function of hn.
% domain:  discrete
% note:    the system autocorrelation function (sacf) is
%
%            sacf = hn[n] * hn[-n]
%
%          where * is convolution. 
%
% inputs:  /hn/       an impulse response
%          /thresh/   sacf threshold, eg 0.05 for 5%. 
% output:  /profile/  structure of sacf-related data
%
% author:  JN Damask
%
%--------------------------------------------------------------------------------------------------

% infer naxis from the length of hn
hn          = hn(:);
Nwindow     = length(hn);
naxis       = [0: Nwindow-1]';

Nsacf       = 2 * Nwindow - 1;
sacf_axis   = [-Nwindow+1: Nwindow-1]'; 
sacf_axis0  = Nwindow;

% compute sacf from convolution
sacf        = conv(hn, flipud(hn));

% find the max value, which is at zero lag
sacf_0      = sacf(sacf_axis0); 

% calc the normalized sacf
sacf_norm   = sacf / sacf_0;

% find the sacf width at the threshold value
index_thresh  = find(sacf_norm(Nwindow: end) < thresh, 1);
sacf_thresh_width = sacf_axis(Nwindow + index_thresh);

% load profile
profile.sacf_axis   = sacf_axis;
profile.sacf_0      = sacf_0;
profile.sacf_norm   = sacf_norm;
profile.sacf_width  = sacf_thresh_width;



