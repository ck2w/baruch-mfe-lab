function hn = compute_fde_polyema_impulse_response(M1, order, Nwindow)

%--------------------------------------------------------------------------------------------------
%
% fcxn:    compute_fde_polyema_impulse_response.m
% descrip: computes the impulse response of a polyema from its fde.
% domain:  discrete
%
% xfer fcxn: this function writes an fde related to
%
%            Hm(z) = (1 - p/m)^m / (1 - p/m z^-1)^m
%
% note:    to have uniform code, the fdes are all implemented as 5th order.
%          zero or more coefficients to the lags of y[n] may be zero. 
% 
% inputs:  /M1/       the first moment 
%          /order/    order of the polyema
% 	       /Nwindow/  the window over which to compute the poly-ema impulse
%                     response
%
% output:  /hn/       the impulse response based on the fde.
%
% author:  JN Damask
%
%--------------------------------------------------------------------------------------------------

% sanity
if (order < 1) || (order > 5),
    disp('order out of bounds:   1 <= order <= 5');
    return
end

max_order = 5;

% poly-ema parameter
m   = order;  % shorthand
p  = M1 / (1 + M1 / m);
pm = p / m;

% compute gain adjustment
gm = (1 - pm)^m;

% expand the Qm(z) polynomial -- here just compute the binomial coefs
pconv = @(poly)( conv([1 -1], poly) );   % anonymous function for poly multiplication
bcoef = [1];                             % starting polynomial of the binomial coefs

for k = 1: m,
    bcoef = pconv(bcoef);
end

% we will have a vector like [1 -3 3 -1]. The 1st term associates with y[n]. 
% The remaining terms will be on the right-hand side, so need a -1 factor.
phi_coef       = zeros(max_order, 1);  % up to 5th order
phi_coef(1: m) = - bcoef(2: end);

% compute pm^m
pm_vec = pm.^[1: max_order]';

% now apply pm_vec to phi_coef's
phi_coef = phi_coef .* pm_vec;

% make input impulse sequence
xn = zeros(Nwindow, 1);
xn(1) = 1;

% manage initial conditions
lags_y = max_order;

xn_pad = [zeros(lags_y, 1); xn]; 
yn_pad = zeros(size(xn_pad));

% run the recursion on xn_pad
for k = 1 + lags_y: length(xn_pad),
    
   yn_pad(k) = phi_coef' * yn_pad(k-1: -1: k-1-lags_y+1) + gm * xn_pad(k);
    
end

% remove the padding
hn = yn_pad(max_order+1: end);




