% script:  study_sampling_and_replication
% descrip: Studies sampling and replication in time and frequency domains.

% Defs
Nwindow = 1024;
Nperiod = 4;


%%
% sample in time domain    <----> replicate in frequency domain

% impulse responses
Neff = 128;
n_ema = [0: 8 * Neff - 1];
N_ema = length(n_ema);
d_ema = Neff / (Neff + 1);

Nbox = round(Neff / (1 - exp(-1)));
nbox = [0: Nbox - 1];

% time
h_box = make_h_box(Nbox, Nwindow);
h_ema = make_h_ema(Neff, Nwindow);

% spectrum
H_box = abs(fft(h_box));
H_ema = abs(fft(h_ema));

% sampling comb in time
h_comb_sample = make_h_comb(Nperiod, Nwindow);

% "sample" the impulse responses
h_box_sampled = h_box .* h_comb_sample;
h_ema_sampled = h_ema .* h_comb_sample;

% switch to frequency domain
H_box_sampled = Nperiod * abs(fft(h_box_sampled));
H_ema_sampled = Nperiod * abs(fft(h_ema_sampled));

% plot figures for comparison
figure(1); clf
for k=1:2, ax(k,1) = subplot(2,1,k); end; linkaxes(ax(:,1), 'x');
axes(ax(1,1)); 
stairs(h_box); grid on; hold on;
stem(h_box_sampled, 'r');
title('Box and its sample')

axes(ax(2,1))
plot(h_ema); grid on; hold on;
stem(h_ema_sampled, 'r');
title('Ema and its sample')

figure(2); clf
for k=1:2, ax(k,2) = subplot(2,1,k); end; linkaxes(ax(:,2), 'x');
axes(ax(1,2));
plot(H_box); grid on; hold on
plot(H_box_sampled, 'r');
title('Box spectrum and its replication')

axes(ax(2,2));
plot(H_ema); grid on; hold on; 
plot(H_ema_sampled, 'r');
title('Ema spectrum and its replication')



%%
% replicate in time domain <----> sample in frequency domain

% impulse responses
Neff = 32;
n_ema = [0: 8 * Neff - 1];
N_ema = length(n_ema);
d_ema = Neff / (Neff + 1);

Nbox = round(Neff / (1 - exp(-1)));
nbox = [0: Nbox - 1];

% time
h_box = make_h_box(Nbox, Nwindow);
h_ema = make_h_ema(Neff, Nwindow);

% sampling comb in time
h_comb_repl = make_h_comb(Nwindow / Nperiod, Nwindow);

% replicate the impulse responses
cand = conv(h_comb_repl, h_box); h_box_repl = cand(1: Nwindow);
cand = conv(h_comb_repl, h_ema); h_ema_repl = cand(1: Nwindow);

% switch to frequency domain
H_box      = abs(fft(h_box));
H_ema      = abs(fft(h_ema));
H_box_repl = abs(fft(h_box_repl)) / Nperiod;
H_ema_repl = abs(fft(h_ema_repl)) / Nperiod;

% plot figures for comparison
figure(3); clf
for k=1:2, ax(k,1) = subplot(2,1,k); end; linkaxes(ax(:,1), 'x');
axes(ax(1,1)); 
stairs(h_box_repl); grid on; hold on;
title('Box and its replication')

axes(ax(2,1))
plot(h_ema_repl); grid on; hold on;
title('Ema and its replication')

figure(4); clf
for k=1:2, ax(k,2) = subplot(2,1,k); end; linkaxes(ax(:,2), 'x');
axes(ax(1,2));
plot(H_box); grid on; hold on
plot(H_box_repl, 'r');
title('Box spectrum and its sample')

axes(ax(2,2));
plot(H_ema); grid on; hold on; 
plot(H_ema_repl, 'r');
title('Ema spectrum and its sample')








