__author__ = 'yifan'
# This script is for Math9893 at Baruch College
# This script refers to hw #4
# Please uncomment each function in main() to test


import matplotlib.pyplot as plt
import math
import numpy as np
import pandas as pd
from scipy.optimize import minimize

import utils_hw4

def study_sampling_and_replication():
    '''
    Studies sampling and replication in time and frequency domains
    :return:
    '''

    Nwindow = 1024
    Nperiod = 4

    ##
    # sample in time domain  <---->  replication in frequency domain

    # impulse response
    Neff = 128
    Nbox = int(round(Neff / (1 - math.exp(-1))))

    # time
    h_box = utils_hw4.make_h_box(Nbox, Nwindow)
    h_ema = utils_hw4.make_h_ema(Neff, Nwindow)

    # spectrum
    H_box = np.abs(np.fft.fft(h_box))
    H_ema = np.abs(np.fft.fft(h_ema))

    # sampling comb in time
    h_comb_sample = utils_hw4.make_h_comb(Nperiod, Nwindow)

    # 'sample' the impulse response
    h_box_sampled = h_box * h_comb_sample
    h_ema_sampled = h_ema * h_comb_sample

    H_box_sample = Nperiod * np.abs(np.fft.fft(h_box_sampled))
    H_ema_sample = Nperiod * np.abs(np.fft.fft(h_ema_sampled))

    # plot figures for comparison
    fig1 = plt.figure()
    ax = [fig1.add_subplot(2, 1, k+1) for k in range(2)]
    ax[0].step(range(len(h_box)), h_box)
    ax[0].grid(True)
    ax[0].stem(h_box_sampled, 'r')
    ax[0].set_title('Box and its sample')
    ax[1].plot(h_ema)
    ax[1].grid(True)
    ax[1].stem(h_ema_sampled, 'r')
    ax[1].set_title('Ema and its sample')


    fig2 = plt.figure()
    ax = [fig2.add_subplot(2, 1, k+1) for k in range(2)]
    ax[0].grid(True)
    ax[0].plot(H_box)
    ax[0].plot(H_box_sample, 'r')
    ax[0].set_title('Box spectrum and its replication')
    ax[1].grid(True)
    ax[1].plot(H_ema)
    ax[1].stem(H_ema_sample, 'r')
    ax[1].set_title('Ema spectrum and its replication')

    ##
    # replication i time domain  <---->  sample in frequency domain

    # impulse response
    Neff = 32
    Nbox = int(round(Neff / (1 - math.exp(-1))))

    # time
    h_box = utils_hw4.make_h_box(Nbox, Nwindow)
    h_ema = utils_hw4.make_h_ema(Neff, Nwindow)

    # sampling comb in time
    h_comb_repl = utils_hw4.make_h_comb(Nwindow / Nperiod, Nwindow)

    # replicate the impulse response
    cand = np.convolve(h_comb_repl, h_box)
    h_box_repl = cand[:Nwindow]
    cand = np.convolve(h_comb_repl, h_ema)
    h_ema_repl = cand[:Nwindow]

    # switch to frequency domain
    H_box = np.abs(np.fft.fft(h_box))
    H_ema = np.abs(np.fft.fft(h_ema))
    H_box_repl = np.abs(np.fft.fft(h_box_repl)) / Nperiod
    H_ema_repl = np.abs(np.fft.fft(h_ema_repl)) / Nperiod

    # plot figures for comparison
    fig3 = plt.figure()
    ax = [fig3.add_subplot(2, 1, k+1) for k in range(2)]
    ax[0].grid(True)
    ax[0].step(range(len(h_box_repl)), h_box_repl)
    ax[0].set_title('Box and its replication')
    ax[1].grid(True)
    ax[1].plot(h_ema_repl)
    ax[1].set_title('Ema and its replication')
    fig4 = plt.figure()
    ax = [fig4.add_subplot(2, 1, k+1) for k in range(2)]
    ax[0].grid(True)
    ax[0].plot(H_box)
    ax[0].plot(H_box_repl, 'r')
    ax[0].set_title('Box spectrum and its sample')
    ax[1].grid(True)
    ax[1].plot(H_ema)
    ax[1].stem(H_ema_repl, 'r')
    ax[1].set_title('Ema spectrum and its sample')

    plt.show()


def main():
    study_sampling_and_replication()


if __name__ == '__main__':
    main()
