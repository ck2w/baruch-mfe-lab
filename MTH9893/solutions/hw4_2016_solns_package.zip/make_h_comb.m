function h = make_h_comb(Nperiod, Nwindow)

% descrip:  returns a finite-sample comb with period Nperiod
%           on window Nwindow. For fft work its best to make
%           Nwindow ~ 2^J, J is some integer. 

h = zeros(Nwindow, 1);
h([1: Nperiod: Nwindow]) = 1;


